import re
import requests
from bs4 import BeautifulSoup
import csv
from top100terms import yolo_terms
import os 
from time import sleep

HEADERS = {
    'User-Agent': ('Mozilla/5.0 (X11; Linux x86_64)'
                    'AppleWebKit/537.36 (KHTML, like Gecko)'
                    'Chrome/44.0.2403.157 Safari/537.36'),
    'Accept-Language': 'en-US, en;q=0.5'
}


def get_url(search_term):
    template = 'https://www.amazon.com/s?k={}&crid=1ETD973V81N4Y&qid=1669676775&sprefix={}%2Caps%2C70&ref=sr_pg_1'
    search_term = search_term.replace(' ', '+')

    #add term query to url 
    url = template.format(search_term, search_term)
    
    url += '&page{}'
    #print(url)
    return url

def extract_record2(item):
    #extract and retrun data from a single record

    #description and url 
    try:
        product_name = item.find('span', 'a-size-base-plus a-color-base a-text-normal').text
        #print(product_name)
        atag = item.h2.a
        product_link = 'https://www.amazon.com'+atag.get('href')
        #print(product_link)
        
        #price
        price_parent = item.find('span', 'a-price')
        price = price_parent.find('span', 'a-offscreen').text
        
        
        parent_image = item.find('div','a-section aok-relative s-image-square-aspect')  
        image_link = (parent_image.find('img').get('src'))
        #print(image_link)
    except AttributeError:
        return
    


    result = (product_name, price, product_link, image_link)
    
    
    return result

def extract_record(item):
    #extract and retrun data from a single record

    #description and url 
    try:
        product_name = item.find('span', 'a-size-medium a-color-base a-text-normal').text
        #print(product_name)
        atag = item.h2.a
        product_link = 'https://www.amazon.com'+atag.get('href')

        parent_image = item.find('div','a-section aok-relative s-image-fixed-height')  
        image_link = (parent_image.find('img').get('src'))
        #price
        price_parent = item.find('span', 'a-price')
        price = price_parent.find('span', 'a-offscreen').text
    except AttributeError:
        print('ran into exception')
        return
        
    

    result = (product_name, price, product_link, image_link)
    
    print(len(result))
    return result




def main(search_term):
    
    #run main program routine 
    records = []
    url = get_url(search_term)

    for page in range(0, 1):
        html = requests.get(url.format(page), headers=HEADERS)
        soup = BeautifulSoup(html.text,features='lxml')
        results = soup.find_all('div', {'data-component-type':'s-search-result'})
       

        for item in results:
            record = extract_record(item)
            if record:
                records.append(record)
        for item in results:
            record = extract_record2(item)
            if record:
                records.append(record)
        
                
                
                    


                           

    #save results to a csv file
    
    with open(directory + '/results.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['item_name','price','link_to_item','link_to_item_image'])
        writer.writerows(records)

for result in yolo_terms:
    #print(result)
    directory = 'G:/Programming/pythonscripts/webscraper/results_folder/' + result
    if not os.path.exists(directory):
        
        os.makedirs(directory)
        os.mkdir(directory + '/images')

        main(result)
        sleep(1)
        


        