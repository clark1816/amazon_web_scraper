#create a program to show the top 100 searched terms on amazon.com
from top100terms import yolo_terms
import os 
for result in yolo_terms:
    print(result)
    directory = 'G:/Programming/pythonscripts/webscraper/results_folder/' + result
    if not os.path.exists(directory):
        os.makedirs(directory)
        os.mkdir(directory + '/images')
        
